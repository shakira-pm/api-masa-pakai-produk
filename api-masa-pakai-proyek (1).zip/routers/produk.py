from fastapi import APIRouter, Depends, HTTPException, Response, status
from dependencies.auth import get_current_user, require_admin
from schemas.produk import ProdukCreate, ProdukResponse, ProdukUpdate

router = APIRouter(tags=["Produk"])

# Penyimpanan sementara di memori; data akan hilang saat runtime dimulai ulang.
db: dict[int, dict] = {}
next_id = 1

@router.get("/produk", response_model=list[ProdukResponse])
def daftar_produk(user=Depends(get_current_user)):
    return list(db.values())

@router.post("/produk", response_model=ProdukResponse, status_code=status.HTTP_201_CREATED)
def tambah_produk(data: ProdukCreate, user=Depends(get_current_user)):
    global next_id
    item = {"id": next_id, **data.model_dump()}
    db[next_id] = item
    next_id += 1
    return item

@router.get("/produk/{produk_id}", response_model=ProdukResponse)
def detail_produk(produk_id: int, user=Depends(get_current_user)):
    item = db.get(produk_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Produk tidak ditemukan.")
    return item

@router.patch("/produk/{produk_id}", response_model=ProdukResponse)
def ubah_produk(produk_id: int, data: ProdukUpdate, user=Depends(require_admin)):
    item = db.get(produk_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Produk tidak ditemukan.")
    perubahan = data.model_dump(exclude_unset=True)
    item.update(perubahan)
    return item

@router.delete("/produk/{produk_id}", status_code=status.HTTP_204_NO_CONTENT)
def hapus_produk(produk_id: int, user=Depends(require_admin)):
    if produk_id not in db:
        raise HTTPException(status_code=404, detail="Produk tidak ditemukan.")
    del db[produk_id]
    return Response(status_code=status.HTTP_204_NO_CONTENT)
